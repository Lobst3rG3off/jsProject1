const pizza = {
	pie: [
		{
			title: 'Maker Pizza',
			price: '$$'
		},
		{	
			title: 'Pizza Libretto',
			price: '$$'
		},
		{
			title: 'Dominoes',
			price: '$'
		}
	],
	slice: [
		{
			title: 'Pizzaiolo',
			price: '$$'
		},
		{
			title: 'North of Brooklyn',
			price: '$$'
		},
		{
			title: 'Pizza Pizza',
			price: '$'
		},
		{
			title: 'King Slice',
			price: '$'
		}
	]	
};

const randomResult = (arr) => {
	const randomNumber = Math.floor(Math.random() * arr.length );
	return arr[randomNumber];
}

$(document).ready(function() {
	$('form').on('submit', function(event) {
		event.preventDefault();
		const userSize = $('input[name=size]:checked').val();
		const userPrice = $('input[name=price]:checked').val();
		const sizeOptions = pizza[userSize];
		const filteredOptions = sizeOptions.filter(rest => rest.price === userPrice);
		const theOne = randomResult(filteredOptions);
		// console.log(theOne);
		const resultHTML = `<h2>You should go to ${theOne.title}</h2>`;
		$('.results').html(resultHTML);
	});
});